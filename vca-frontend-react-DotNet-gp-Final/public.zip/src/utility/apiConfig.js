export const BASE_URL = "http://localhost:5252/api";

export const CURRENT_BASE_URL = "http://localhost:3000";