import p from './p.webp'

export { p }
