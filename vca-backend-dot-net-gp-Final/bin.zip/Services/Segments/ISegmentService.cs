﻿using VCA.Models;
namespace VCA.Services.Segments
{
    public interface ISegmentService
    {
        List<Segment> GetAllSegments();
    }
}
